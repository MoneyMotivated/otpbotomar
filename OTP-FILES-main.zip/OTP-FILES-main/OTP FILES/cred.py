#Twilio Details

account_sid = 'AC677a3d0ea30b29ec95079fa42b779dc8'
auth_token = '6bd82e7d2372ad977759e13b83d7dbc1'
twilionumber = '+16165778046'
twiliosmsnumber = '+16165778046'

#FC Bot
API_TOKEN = "5578275728:AAH2jqBDedlu6MF6wM-Pu3yatytaVTbheX8"

#Host URL
callurl = 'https://a3702bf898c2.ngrok.io'
twiliosmsurl = 'https://a3702bf898c2.ngrok.io/sms'









